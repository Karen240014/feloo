$(document).ready(function(){
	$(".div1-a").click(function(){
		$(".menu").removeClass("Lmenu")
	})
	$(".a11").click(function(){
		$(".menu").addClass("Lmenu")
	})
})





