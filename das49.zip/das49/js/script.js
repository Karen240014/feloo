$(document).ready(function () {
	$(".m").click(function () {
		$(".menu_js").removeClass("dn")
	})
	$(".spun1").click(function () {
		$(".menu_js").addClass("dn")
	})
	$(".c").click(function () {
		$(".contact_js").removeClass("dn")
	})
	$(".btn2").click(function () {
		$(".contact_js").addClass("dn")
	})
	$(".spun1").click(function () {
		$(".contact_js").addClass("dn")
	})
})