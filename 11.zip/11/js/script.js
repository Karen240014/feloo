$(document).ready(function () {
	$(".burger").click(function () {
		$(".js_menu").removeClass("dn")
	})
	$(".js_i").click(function () {
		$(".js_menu").addClass("dn" ,3000)
	})
})